
package main;

import carro.Carro;
import moto.Moto;
import veiculo.Veiculo;

public class Main {
    
    public static void acelerar(Veiculo veiculo){
    
        if(veiculo instanceof Moto){
        ((Moto) veiculo).empinar();
            
        }else if(veiculo instanceof Carro){
        ((Carro) veiculo).drift();
        
        }
    }
    
    public static void main(String[] args) {
        
        Moto moto = new Moto();
        Carro carro = new Carro();
        
        moto.setCor("Preta");
        carro.setCor("Azul");
        
        moto.setManete("Azul com led");
        carro.setVolante("Revestido em Couro");
        
      acelerar(carro);
      acelerar(moto);
}
}
