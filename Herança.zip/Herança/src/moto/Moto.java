
package moto;

import veiculo.Veiculo;


public class Moto extends Veiculo{
    
    private String guidao;
    private String macaco;
    private String manete;
 
    
    public void empinar(){
        System.out.println("Empinando!!!" + "Raioo.. Deu ruim!");
    }
    /**
     * @return the guidao
     */
    public String getGuidao() {
        return guidao;
    }

    /**
     * @param guidao the guidao to set
     */
    public void setGuidao(String guidao) {
        this.guidao = guidao;
    }

    /**
     * @return the macaco
     */
    public String getMacaco() {
        return macaco;
    }

    /**
     * @param macaco the macaco to set
     */
    public void setMacaco(String macaco) {
        this.macaco = macaco;
    }

    /**
     * @return the manete
     */
    public String getManete() {
        return manete;
    }

    /**
     * @param manete the manete to set
     */
    public void setManete(String manete) {
        this.manete = manete;
    }
    
    
}
