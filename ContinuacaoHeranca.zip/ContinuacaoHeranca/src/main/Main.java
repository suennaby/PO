
package main;

import conta.ContaCorrente;
import conta.ContaPoupanca;


public class Main {
    
    public static void main(String[] args) {
        ContaPoupanca cp = new ContaPoupanca("123-2", "123-3", 0.9);
        
        ContaCorrente cr = new ContaCorrente("123-2", "123-32", 20.53);
        
        
        System.out.println(cp.getNumeroAgencia());
        System.out.println(cp.getNumeroConta());
        System.out.println(cp.getPorcentagemJurosMensal());
        cp.deposito(cp, 1000);
        
        System.out.println("### CONTA CORRENTE ###");
        
        System.out.println(cr.getNumeroAgencia());
        System.out.println(cr.getNumeroConta());
        System.out.println(cr.getPorcetagemImpostoMensal());
        cr.deposito(cr, 1000);
    }
    
}
