
package conta;


public class ContaCorrente extends Conta{
    
    private double PorcetagemImpostoMensal;
    
    public ContaCorrente( String conta, String agencia, double pc){
        super(conta, agencia);
        this.PorcetagemImpostoMensal = pc;
        
    }

    /**
     * @return the porcetagemImpostoMensal
     */
    public double getPorcetagemImpostoMensal() {
        return PorcetagemImpostoMensal;
    }

    /**
     * @param porcetagemImpostoMensal the porcetagemImpostoMensal to set
     */
    public void setPorcetagemImpostoMensal(double porcetagemImpostoMensal) {
        this.PorcetagemImpostoMensal = PorcetagemImpostoMensal;
    }
}
