
package conta;

public class ContaPoupanca extends Conta{
     
    private double porcentagemJurosMensal;
    
    public ContaPoupanca (String conta, String agencia, double pc){
       super(conta, agencia);
       this.porcentagemJurosMensal = pc;
       
    }

    /**
     * @return the porcentagemJurosMensal
     */
    public double getPorcentagemJurosMensal() {
        return porcentagemJurosMensal;
    }

    /**
     * @param porcentagemJurosMensal the porcentagemJurosMensal to set
     */
    public void setPorcentagemJurosMensal(double porcentagemJurosMensal) {
        this.porcentagemJurosMensal = porcentagemJurosMensal;
    }
}
