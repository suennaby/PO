
package Aparelho;


public class Fone extends Aparelho{
    private String tamanho;
    private String cor;
    public Fone(String modelo,String valor,String cor, String tamanho){
        
       super(modelo, valor);
       this.cor = cor;
       this.tamanho = tamanho;
    }

    /**
     * @return the tamanho
     */
    public String getTamanho() {
        return tamanho;
    }

    /**
     * @param tamanho the tamanho to set
     */
    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @param cor the cor to set
     */
    public void setCor(String cor) {
        this.cor = cor;
    }
}
