
package Aparelho;


public class SmartBand extends Aparelho{
    private String cor;
    private String marca;
    public SmartBand(String modelo,String valor, String cor, String marca){
        
       super(modelo, valor);
       this.cor = cor;
       this.marca = marca;
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @param cor the cor to set
     */
    public void setCor(String cor) {
        this.cor = cor;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
}
