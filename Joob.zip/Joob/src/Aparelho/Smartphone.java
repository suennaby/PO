
package Aparelho;


public class Smartphone extends Aparelho{
    private String armazenamento;
    private String marca;
    
    public Smartphone(String modelo,String valor, String armazenamento,String marca){
        
       super(modelo, valor);
       this.armazenamento = armazenamento;
       this.marca = marca;
                    
              
    }

    /**
     * @return the armazenamento
     */
    public String getArmazenamento() {
        return armazenamento;
    }

    /**
     * @param armazenamento the armazenamento to set
     */
    public void setArmazenamento(String armazenamento) {
        this.armazenamento = armazenamento;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    }
    

