
package Aparelho;


public class Computador extends Aparelho{
    
    private String processador;
    private String marcaPc;
    
    public Computador(String modelo,String valor, String processador, String marcaPc){
        
       super(modelo, valor);
       this.processador = processador;
       this.marcaPc = marcaPc;
                    
              
    }

    /**
     * @return the processador
     */
    public String getProcessador() {
        return processador;
    }

    /**
     * @param processador the processador to set
     */
    public void setProcessador(String processador) {
        this.processador = processador;
    }

    /**
     * @return the marcaPc
     */
    public String getMarcaPc() {
        return marcaPc;
    }

    /**
     * @param marcaPc the marcaPc to set
     */
    public void setMarcaPc(String marcaPc) {
        this.marcaPc = marcaPc;
    }
}
