
package Aparelho;


public class Tv extends Aparelho{
    
    private String polegadas;
    private String marcaTv;
    
    public Tv(String modelo,String valor, String polegadas,String marcaTv){
        
       super(modelo, valor);
       this.polegadas = polegadas;
       this.marcaTv = marcaTv;
                    
              
    }

    /**
     * @return the polegadas
     */
    public String getPolegadas() {
        return polegadas;
    }

    /**
     * @param polegadas the polegadas to set
     */
    public void setPolegadas(String polegadas) {
        this.polegadas = polegadas;
    }

    /**
     * @return the marcaTv
     */
    public String getMarcaTv() {
        return marcaTv;
    }

    /**
     * @param marcaTv the marcaTv to set
     */
    public void setMarcaTv(String marcaTv) {
        this.marcaTv = marcaTv;
    }
}
