
package Main;

import Aparelho.Smartphone;


public class Main {
    
    
    public static void main(String[] args) {
        Smartphone smart1 = new Smartphone("6s", "2.000","64g","Apple");
        
        System.out.println(smart1.getArmazenamento());
    }
}
